#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 20 19:53:23 2025

@author: amriksen
"""

import numpy as np
from matplotlib.animation import FuncAnimation
from spring_simulation.parameters import k, m, g, y0, v0, times, time_step
from spring_simulation.rk4_solver import solve_system
from spring_simulation.animation import setup_plot, update

# Solve the system using RK4
positions, _ = solve_system(y0, v0, times, time_step, k, m, g)

# Adjust z-limits based on position range
z_min = min(positions) - 0.5
z_max = max(positions) + 0.5

# Set up the plot
fig, ax, spring_line, mass_sphere = setup_plot(z_min, z_max)

# Create the animation
ani = FuncAnimation(
    fig, update, frames=len(positions), interval=10, blit=True,
    fargs=(positions, z_max, spring_line, mass_sphere)
)

# Save the animation as an MP4 file
ani.save('vertical_spring_mass_system.gif', writer='pillow', fps=30, dpi=150)

#plt.show()
