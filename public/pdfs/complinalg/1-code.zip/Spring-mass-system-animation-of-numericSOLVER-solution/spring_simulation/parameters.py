#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 20 19:55:41 2025

@author: amriksen
"""

import numpy as np

# Parameters
k = 10  # Spring constant
m = 5.0  # Mass
y0 = 0.5  # Initial displacement
v0 = 0.0  # Initial velocity
g = 9.8  # Gravitational acceleration
time_step = 0.01  # Time step for RK4
total_time = 20  # Total simulation time
num_steps = int(total_time / time_step)  # Number of steps
times = np.linspace(0, total_time, num_steps)  # Time array
