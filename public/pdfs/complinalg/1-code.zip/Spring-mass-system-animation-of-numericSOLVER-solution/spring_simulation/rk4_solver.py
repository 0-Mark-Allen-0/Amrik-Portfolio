#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 20 19:54:57 2025

@author: amriksen
"""

def derivatives(y, v, k, m, g):
    """Return dy/dt and dv/dt for the system."""
    dydt = v
    dvdt = -k / m * y + g
    return dydt, dvdt

def rk4(y, v, t, dt, k, m, g):
    """Perform a single step of the RK4 method."""
    # Step 1
    dydt1, dvdt1 = derivatives(y, v, k, m, g)
    k1y, k1v = dt * dydt1, dt * dvdt1

    # Step 2
    dydt2, dvdt2 = derivatives(y + k1y / 2, v + k1v / 2, k, m, g)
    k2y, k2v = dt * dydt2, dt * dvdt2

    # Step 3
    dydt3, dvdt3 = derivatives(y + k2y / 2, v + k2v / 2, k, m, g)
    k3y, k3v = dt * dydt3, dt * dvdt3

    # Step 4
    dydt4, dvdt4 = derivatives(y + k3y, v + k3v, k, m, g)
    k4y, k4v = dt * dydt4, dt * dvdt4

    # Combine steps
    y_next = y + (k1y + 2 * k2y + 2 * k3y + k4y) / 6
    v_next = v + (k1v + 2 * k2v + 2 * k3v + k4v) / 6

    return y_next, v_next

def solve_system(y0, v0, times, dt, k, m, g):
    """Solve the system using RK4 and return positions and velocities."""
    num_steps = len(times)
    positions = [y0]
    velocities = [v0]
    y, v = y0, v0

    for i in range(1, num_steps):
        y, v = rk4(y, v, times[i - 1], dt, k, m, g)
        positions.append(y)
        velocities.append(v)

    return positions, velocities
