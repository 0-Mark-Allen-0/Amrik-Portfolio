#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 20 19:54:27 2025

@author: amriksen
"""

import numpy as np

def create_spring(start, end, coils=10, radius=0.1):
    """Generate a helical spring from start to end."""
    t = np.linspace(0, 2 * np.pi * coils, 300)
    x = radius * np.sin(t)
    y = radius * np.cos(t)
    z = np.linspace(start, end, t.size)
    return x, y, z
