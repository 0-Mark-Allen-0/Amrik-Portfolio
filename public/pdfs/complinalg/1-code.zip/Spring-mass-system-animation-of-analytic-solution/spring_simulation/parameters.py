#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 20 18:39:55 2025

@author: amriksen
"""

import numpy as np

# Parameters
k = 10.0  # Spring constant
m = 5.0  # Mass
y0 = 0.5  # Initial displacement
time_step = 0.01  # Time step
total_time = 20  # Total simulation time
g = 9.8  # Gravitational acceleration

# Derived parameters
omega = np.sqrt(k / m) * 3
num_frames = int(total_time / time_step)
times = np.linspace(0, total_time, num_frames)
positions = y0 * np.cos(omega * times) + (m * g / k) * (1 - np.cos(omega * times))
