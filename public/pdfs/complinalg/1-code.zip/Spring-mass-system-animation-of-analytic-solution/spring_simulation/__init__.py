#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 20 18:47:33 2025

@author: amriksen
"""

#__init__.py