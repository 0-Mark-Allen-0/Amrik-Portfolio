#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 20 18:44:26 2025

@author: amriksen
"""

import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from mpl_toolkits.mplot3d import Axes3D
from .spring import create_spring

def setup_plot(z_min, z_max):
    """Set up the 3D plot for the simulation."""
    fig = plt.figure(figsize=(8, 6))
    ax = fig.add_subplot(111, projection='3d')
    ax.set_xlim(-0.5, 0.5)
    ax.set_ylim(-0.5, 0.5)
    ax.set_zlim(z_min, z_max)
    ax.plot([-0.5, 0.5], [0, 0], [z_max, z_max], color='black', linewidth=4)  # Ceiling
    spring_line, = ax.plot([], [], [], color='blue', linewidth=2)
    mass_sphere, = ax.plot([], [], [], 'o', markersize=20, color='red')
    return fig, ax, spring_line, mass_sphere

def update(frame, positions, z_max, spring_line, mass_sphere):
    """Update the spring and mass position."""
    z = positions[frame]
    spring_x, spring_y, spring_z = create_spring(z_max, z)
    spring_line.set_data(spring_x, spring_y)
    spring_line.set_3d_properties(spring_z)
    mass_sphere.set_data([0], [0])
    mass_sphere.set_3d_properties([z])
    return spring_line, mass_sphere
