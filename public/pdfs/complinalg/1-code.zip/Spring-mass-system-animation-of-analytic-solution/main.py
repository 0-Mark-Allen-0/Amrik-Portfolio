#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Jan 20 18:45:18 2025

@author: amriksen
"""

import numpy as np
from matplotlib.animation import FuncAnimation
import matplotlib.pyplot as plt
from spring_simulation.parameters import k, m, g, positions, num_frames, time_step
from spring_simulation.animation import setup_plot, update

# Calculate z-limits
z_min = min(positions) - 0.5
z_max = max(positions) + 0.5

# Set up the plot
fig, ax, spring_line, mass_sphere = setup_plot(z_min, z_max)

# Create the animation
ani = FuncAnimation(
    fig,
    update,
    frames=num_frames,
    interval=10,
    blit=True,
    fargs=(positions, z_max, spring_line, mass_sphere),
)

# Save the animation
ani.save('vertical_spring_mass_system.gif', writer='pillow', fps=30, dpi=150)
#ani.save('vertical_spring_mass_system.mp4', writer='ffmpeg', fps=30, dpi=150)

plt.show()
